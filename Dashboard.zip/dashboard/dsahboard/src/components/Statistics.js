// src/components/Statistics.js
import React from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import './Statistics.css';

const logs = [
  { level: 'INFO' },
  { level: 'ERROR' },
  { level: 'WARN' },
  { level: 'DEBUG' },
  { level: 'ERROR' },
  { level: 'INFO' },
  { level: 'INFO' },
  { level: 'WARN' },
];

const COLORS = ['#0088FE', '#FF8042', '#FFBB28', '#00C49F'];

const getLogLevelData = () => {
  const counts = logs.reduce((acc, log) => {
    acc[log.level] = (acc[log.level] || 0) + 1;
    return acc;
  }, {});
  return Object.entries(counts).map(([name, value]) => ({ name, value }));
};

const Statistics = () => {
  const data = getLogLevelData();

  return (
    <div className="statistics">
      <h2>Log Level Distribution</h2>
      <ResponsiveContainer width="100%" height={400}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            outerRadius={130}
            label
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default Statistics;
