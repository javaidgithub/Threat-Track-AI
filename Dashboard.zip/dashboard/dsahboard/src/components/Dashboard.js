import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Dashboard.css';

const logs = [
  { id: 1, level: 'INFO', message: 'System started', timestamp: '2025-05-02 10:01:12' },
  { id: 2, level: 'ERROR', message: 'Database connection failed', timestamp: '2025-05-02 10:03:45' },
  { id: 3, level: 'WARN', message: 'High memory usage', timestamp: '2025-05-02 10:06:12' },
  { id: 4, level: 'DEBUG', message: 'Auth token refreshed', timestamp: '2025-05-02 10:09:52' },
];

const LogRow = ({ log }) => (
  <tr className={`log-row ${log.level.toLowerCase()}`}>
    <td>{log.timestamp}</td>
    <td>{log.level}</td>
    <td>{log.message}</td>
  </tr>
);

const Dashboard = () => {
  const [searchTerm, setSearchTerm] = useState('');

  // Filter logs based on the search keyword
  const filteredLogs = logs.filter(log =>
    log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.level.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.timestamp.includes(searchTerm)
  );

  return (
    <div className="dashboard">
      <aside className="sidebar">
        <h2>Threat-Track-AI</h2>
        <nav>
        <ul>
  <li><Link to="/dashboard/logs" className="sidebar-link">Logs</Link></li>
  <li><Link to="/dashboard/statistics" className="sidebar-link">Statistics</Link></li>
  <li><Link to="/dashboard/settings" className="sidebar-link">Settings</Link></li>
  <li><Link to="/dashboard/upload" className="sidebar-link">Upload Logs</Link></li>
  <li><Link to="/dashboard/live" className="sidebar-link">Live Stream</Link></li>
  <li><Link to="/dashboard/system" className="sidebar-link">System Info</Link></li>
  <li><Link to="/dashboard/alerts" className="sidebar-link">Alerts</Link></li>
</ul>

        </nav>
      </aside>

      <main className="main-content">
        <header>
          <h1>Log Analysis</h1>
          <span className="timestamp">{new Date().toLocaleString()}</span>
        </header>

        {/* 🔍 Search Input */}
        <input
          type="text"
          placeholder="Search logs by keyword..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="log-search"
        />

        <section className="logs-table">
          <h2>Recent Logs</h2>
          <table>
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>Level</th>
                <th>Message</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs.map(log => (
                <LogRow key={log.id} log={log} />
              ))}
            </tbody>
          </table>
        </section>
      </main>
    </div>
  );
};

export default Dashboard;
